
  # Diseñar interfaz web minimalista (copia)

  This is a code bundle for Diseñar interfaz web minimalista (copia). The original project is available at https://www.figma.com/design/YvK7jqZtREJAKXQHtQ3fdA/Dise%C3%B1ar-interfaz-web-minimalista--copia-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  